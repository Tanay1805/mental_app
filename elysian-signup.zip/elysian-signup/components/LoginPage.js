import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons'; // Assuming you're using Expo for vector icons
import ToggleButton from './ToggleButton';

const isValidEmail = (email) => {
  const regex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
  return regex.test(email);
};

const isValidPhoneNumber = (phoneNumber) => {
  const regex = /^\d{10}$/;
  return regex.test(phoneNumber);
};

const LoginPage = ({ title, isLogin, toggleLogin }) => {
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  const handleLogin = () => {
    if ((email && !isValidEmail()) || (phoneNumber && !isValidPhoneNumber())) {
      Alert.alert("Success");
      return;
    } else {
      if (!isValidEmail(email)) {
        Alert.alert('Invalid email format');
        return;
      }

      if (!isValidPhoneNumber(phoneNumber)) {
        Alert.alert(
          'Invalid phone number format. Please enter exactly 10 digits.'
        );
        return;
      }
    }
    // Handle login logic here
    console.log('Email:', email);
    console.log('Phone Number:', phoneNumber);
  };

  return (
    <View style={styles.container}>
      {/* Semicircle */}
      <View style={styles.semicircle} />

      {/* Title */}
      <Text style={styles.title}>{title}</Text>

      {/* Username Input */}
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
      />

      {/* Phone Number Input */}
      <TextInput
        style={styles.input}
        placeholder="Phone Number"
        keyboardType="phone-pad"
        value={phoneNumber}
        onChangeText={setPhoneNumber}
        maxLength={10}
      />

      {/* Login Button */}
      <TouchableOpacity
        style={[styles.button, { backgroundColor: '#69B2A0' }]}
        onPress={handleLogin}>
        <Text style={styles.buttonText}>
          {isLogin ? 'Login' : 'Create Account'}
        </Text>
      </TouchableOpacity>

      {/* Toggle Button */}
      <ToggleButton isLogin={isLogin} toggleLogin={toggleLogin} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#eaeee5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  semicircle: {
    width: '100%',
    height: 250,
    backgroundColor: '#69B2A0',
    borderBottomLeftRadius: 200,
    borderBottomRightRadius: 200,
    transform: [{ scaleX: 2 }],
    position: 'absolute',
    top: 0,
    zIndex: -1,
  },
  title: {
    fontSize: 24,
    color: '#69B2A0',
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    width: '80%',
    backgroundColor: '#f2f2f2',
    padding: 10,
    borderRadius: 40,
    marginBottom: 10,
    borderWidth: 2,
    borderColor: '#9AB268',
    borderBlockStartColor: '#9ab268',
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#69B2A0',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    marginVertical: 10,
  },
  buttonText: {
    color: 'white',
    marginLeft: 0,
  },
});

export default LoginPage;
