import React, { useState } from 'react';
import { View } from 'react-native';
import LoginPage from './components/LoginPage';
import ToggleButton from './components/ToggleButton';

const App = () => {
  const [isLogin, setIsLogin] = useState(true);

  const toggleLogin = () => {
    setIsLogin(!isLogin);
  };

  return (
    <View style={{ flex: 1 }}>
      <LoginPage title={isLogin ? 'Sign In' : 'Sign Up'} isLogin={isLogin} toggleLogin={toggleLogin} />
      <ToggleButton isLogin={isLogin} toggleLogin={toggleLogin} />
    </View>
  );
};

export default App;