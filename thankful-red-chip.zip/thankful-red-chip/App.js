import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';
import { FontAwesome } from '@expo/vector-icons'; // Assuming you're using Expo for vector icons

const LoginPage = () => {
  const [username, setUsername] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isLogin, setIsLogin] = useState(true);

  const handleLogin = () => {
    // Handle login logic here
    console.log('Username:', username);
    console.log('Phone Number:', phoneNumber);
  };

  const toggleLogin = () => {
    setIsLogin(!isLogin);
  };

  return (
    <View style={styles.container}>
      {/* Semicircle */}
      <View style={styles.semicircle} />

      {/* Username Input */}
      <TextInput
        style={styles.input}
        placeholder="Username"
        value={username}
        onChangeText={setUsername}
      />

      {/* Phone Number Input */}
      <TextInput
        style={styles.input}
        placeholder="Phone Number"
        keyboardType="phone-pad"
        value={phoneNumber}
        onChangeText={setPhoneNumber}
      />

      {/* Google Sign-In Button */}
      <TouchableOpacity style={styles.button}>
        <FontAwesome name="google" size={24} color="white" />
        <Text style={styles.buttonText}>Sign in with Google</Text>
      </TouchableOpacity>

      {/* Apple Sign-In Button */}
      <TouchableOpacity style={[styles.button, { backgroundColor: '#000' }]}>
        <FontAwesome name="apple" size={24} color="white" />
        <Text style={styles.buttonText}>Sign in with Apple</Text>
      </TouchableOpacity>

      {/* Login Button */}
      <TouchableOpacity style={[styles.button, { backgroundColor: '#4CAF50' }]} onPress={handleLogin}>
        <Text style={styles.buttonText}>{isLogin ? 'Login' : 'Create Account'}</Text>
      </TouchableOpacity>

      {/* Toggle Button */}
      <TouchableOpacity style={styles.toggleButton} onPress={toggleLogin}>
        <Text style={styles.toggleButtonText}>
          {isLogin ? 'Create an account' : 'Already have an account? Log in'}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  semicircle: {
    width: '100%',
    height: 50,
    backgroundColor: 'green',
    borderBottomLeftRadius: 200,
    borderBottomRightRadius: 200,
    transform: [{ scaleX: 2 }],
    position: 'absolute',
    top: 0,
    zIndex: -1,
  },
  input: {
    width: '80%',
    backgroundColor: '#f2f2f2',
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4285F4',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
    marginVertical: 10,
  },
  buttonText: {
    color: 'white',
    marginLeft: 10,
  },
  toggleButton: {
    backgroundColor: '#ddd',
    padding: 10,
    borderRadius: 8,
    marginTop: 20,
  },
  toggleButtonText: {
    color: '#333',
    fontWeight: 'bold',
  },
});

export default LoginPage;
